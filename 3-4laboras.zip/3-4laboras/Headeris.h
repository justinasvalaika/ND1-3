#ifndef HEADERIS_H_INCLUDED
#define HEADERIS_H_INCLUDED
#include <iostream>
#include <vector>
#include <algorithm>
#include <iomanip>
#include <fstream>

using namespace std;


#endif // HEADERIS_H_INCLUDED
